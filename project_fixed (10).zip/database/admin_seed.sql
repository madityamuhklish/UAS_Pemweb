
UPDATE `users` SET `role` = 'admin' WHERE `email` = 'admin@gmail.com';



